#include "LibInterface.hh"
  
  LibInterface::LibInterface()
  {
    void *pLibHnd_Move = dlopen("libInterp4Move.so",RTLD_LAZY);
    Interp4Command *(*pCreateCmd_Move)(void);
    void *pFun;



    if (!pLibHnd_Move) {
      cerr << "!!! Brak biblioteki: Interp4Move.so" << endl;
      return 1;
    }


    pFun = dlsym(pLibHnd_Move,"CreateCmd");
    if (!pFun) {
      cerr << "!!! Nie znaleziono funkcji CreateCmd" << endl;
      return 1;
    }
    pCreateCmd_Move = *reinterpret_cast<Interp4Command* (**)(void)>(&pFun);

    delete pCmd;    
  }


  LibInterface::~LibInterface()
  {
    dlclose(pLibHnd_Move);
  }


