#include "Set4LibInterfaces.hh"

Set4LibInterfaces::Set4LibInterfaces()
{
    
}

void Set4LibInterfaces::LibRead()
{
    LibList.insert(make_pair("Move", move));
    LibList.insert(make_pair("Set", set));
    LibList.insert(make_pair("Rotate", rotate));
    LibList.insert(make_pair("Pause", pause));
}

bool Set4LibInterfaces::ParamOpen(istringstream &StringStream, Set4LibInterfaces LibraryOpen)
{
    string pomStr;
    LibInterface *pomLib;
    Interp4Command *pomCMD;

    while (StringStream >> pomStr)
    {
        if (LibraryOpen.LibList.find(pomStr) == LibraryOpen.LibList.end())
        {
            cerr << "Error 404! Komendy .... " << pomStr << " .... nie znaleziono." << endl;
            break;
        }

        pomCMD = LibraryOpen.LibList[pomStr]->pCreateCmd();

        if (!pomCMD->ReadParams(StringStream))
        {
            cerr << "Blad wczytywania parametrow!" << endl;
        }

        pomCMD->PrintCmd();
    }
    
    return 0;
}


Set4LibInterfaces::~Set4LibInterfaces()
{
    
}