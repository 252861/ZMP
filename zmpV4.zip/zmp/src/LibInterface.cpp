#include "LibInterface.hh"

  using std::endl;
  using std::cout;
  
  LibInterface::LibInterface(std::string path)
  {
    LibHandler = dlopen(path.c_str(),RTLD_LAZY);


    if (!LibHandler) {
      std::cerr << "!!! Brak biblioteki: " << path << endl;
    }

    void* pFun;
    pFun = dlsym(LibHandler,"CreateCmd");
    if (!pFun) {
      std::cerr << "!!! Nie znaleziono funkcji CreateCmd" << endl;
    }
    pCreateCmd = *reinterpret_cast<Interp4Command* (**)(void)>(&pFun);

    Interp4Command *pCmd = pCreateCmd();

    cout << endl;
    cout << pCmd->GetCmdName() << endl;
    cout << endl;
    pCmd->PrintSyntax();
    cout << endl;
    pCmd->PrintCmd();
    cout << endl;

    delete pCmd;    
  }


  LibInterface::~LibInterface()
  {
    dlclose(LibHandler);
  }


