#include "Set4LibInterfaces.hh"

using namespace std;

bool Set4LibInterfaces::init(vector<string> myLibVector)
{
    for (int i = 0; i < myLibVector.size(); i++)
    {
        shared_ptr<LibInterface> myTempLib = make_shared<LibInterface>();
        myTempLib->init("libs/" + myLibVector[i]);
        string command_name = myLibVector[i].substr(10, myLibVector[i].length() - 13);
        cout << command_name << endl;

        libraries.insert(make_pair(command_name, myTempLib));
    }
    return 0;
}

bool Set4LibInterfaces::execute(istringstream &stream)
{
    string key;
    shared_ptr<LibInterface> handle;
    Interp4Command *command;

    while (stream >> key)
    {
        map<string, shared_ptr<LibInterface>>::iterator iterator = libraries.find(key);
        if (iterator == libraries.end())
        {
            cout << "Nie znaleziono wtyczki dla polecenia: " << key << endl;
            return 1;
        }

        handle = iterator->second;
        command = handle->CreateCmd();
        command->ReadParams(stream);
        cout << "Polecenie:" << endl;
        command->PrintCmd();
        delete command;
    }

    return 0;
}
