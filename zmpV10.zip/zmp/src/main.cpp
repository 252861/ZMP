#include <iostream>
#include <thread>
#include <dlfcn.h>
#include <cassert>
#include "Interp4Command.hh"
#include "MobileObj.hh"
#include "LibInterface.hh"
#include "Reader.hh"
#include "Set4LibInterfaces.hh"
#include "Scene.hh"
#include "Sender.hh"

using namespace std;

int main()
{
  Configuration     myConfig;
  Reader            myReader;
  Set4LibInterfaces myLibHandler;
  istringstream     myStream;
  myReader.init("task.cmd");
  myReader.execPreprocesor(myStream);

  if (!myReader.ReadFile("config/config.xml", myConfig)) return 1;

  Scene   myScene(myConfig);
  Sender  mySender(&myScene);

  if (!mySender.OpenConnection()) return 1;

  thread Thread4Sending(&Sender::Watching_and_Sending, &mySender);

  myLibHandler.init(myConfig.getLibraries());
  myLibHandler.execute(myStream);

  const char *sConfigCmds =
      "Clear\n"
      "AddObj Name=Podstawa1 RGB=(20,200,200) Scale=(4,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,20) Trans_m=(-1,3,0)\n"
      "AddObj Name=Podstawa1.Ramie1 RGB=(200,0,0) Scale=(3,3,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(4,0,0)\n"
      "AddObj Name=Podstawa1.Ramie1.Ramie2 RGB=(100,200,0) Scale=(2,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(3,0,0)\n"
      "AddObj Name=Podstawa2 RGB=(20,200,200) Scale=(4,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(-1,-3,0)\n"
      "AddObj Name=Podstawa2.Ramie1 RGB=(200,0,0) Scale=(3,3,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(4,0,0)\n"
      "AddObj Name=Podstawa2.Ramie1.Ramie2 RGB=(100,200,0) Scale=(2,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(3,0,0)\n";

  mySender.Send(sConfigCmds);
  mySender.Send("Close\n");
  mySender.CancelCountinueLooping();

  Thread4Sending.join();

  return 0;
}
