#pragma once

#include <iostream>
#include <string>
#include <cstdio>
#include <sstream>
#include <list>
#include <xercesc/sax2/SAX2XMLReader.hpp>
#include <xercesc/sax2/XMLReaderFactory.hpp>
#include <xercesc/sax2/DefaultHandler.hpp>
#include <xercesc/util/XMLString.hpp>
#include "Configuration.hh"
#include "xmlinterp.hh"

#define LINE_SIZE 500

using namespace std;

class Reader
{
private:
    string cmdFileName;

public:
    Reader(){};
    bool init(string cmdFile);
    bool execPreprocesor(istringstream &IStrm4Cmds);
    bool ReadFile(const char* sFileName, Configuration &rConfig);
};