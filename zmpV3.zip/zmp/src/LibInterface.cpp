#include "LibInterface.hh"

  std::endl;
  std::cout;
  
  LibInterface::LibInterface(std::string path)
  {
    LibHandler = dlopen(path.c_str(),RTLD_LAZY);


    if (!LibHandler) {
      cerr << "!!! Brak biblioteki: " << path << endl;
      return 1;
    }

    void* pFun;
    pFun = dlsym(LibHandler,"CreateCmd");
    if (!pFun) {
      cerr << "!!! Nie znaleziono funkcji CreateCmd" << endl;
      return 1;
    }
    pCreateCmd = *reinterpret_cast<Interp4Command* (*)(void)>(&pFun);

    Interp4Command *pCmd = pCreateCmd();

    cout << endl;
    cout << pCmd->GetCmdName() << endl;
    cout << endl;
    pCmd->PrintSyntax();
    cout << endl;
    pCmd->PrintCmd();
    cout << endl;

    delete pCmd;    
  }


  LibInterface::~LibInterface()
  {
    dlclose(pLibHnd_Move);
  }


