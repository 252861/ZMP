// Jakub Ggorowski
// 252861
// 
// wersja: 7
//   data: 16.11.2022

#include <iostream>
#include <dlfcn.h>
#include <cassert>
#include <cstdio>
#include <sstream>
#include "LibInterface.hh"
#include "Interp4Command.hh"
#include "MobileObj.hh"
#include "Set4LibInterfaces.hh"
#include "xmlinterp.hh"
#include "Reader.hh"
#include "Scene.hh"
#include "Sender.hh"

using namespace std;

int main()
{
  Configuration Config;
  Reader reader;
  Set4LibInterfaces LibraryOpen;
  istringstream StringStream;
  reader.init("task.cmd");
  reader.execPreprocesor(StringStream);

  LibraryOpen.LibRead();
  LibraryOpen.ParamOpen(StringStream, LibraryOpen);

  if (!reader.ReadFile("config/config.xml", Config))
  {
    return 1;
  }
 
 Scene scene(Config);
  Sender sender(&scene);
  if (!sender.OpenConnection())
    return 1;

  thread Thread4Sending(&Sender::Watching_and_Sending, &sender);

  LibraryOpen.init(Config.getLibraries());
  LibraryOpen.execute(StringStream);

  const char *sConfigCmds =
      "Clear\n"
      "AddObj Name=Podstawa1 RGB=(20,200,200) Scale=(4,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,20) Trans_m=(-1,3,0)\n"
      "AddObj Name=Podstawa1.Ramie1 RGB=(200,0,0) Scale=(3,3,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(4,0,0)\n"
      "AddObj Name=Podstawa1.Ramie1.Ramie2 RGB=(100,200,0) Scale=(2,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(3,0,0)\n"
      "AddObj Name=Podstawa2 RGB=(20,200,200) Scale=(4,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(-1,-3,0)\n"
      "AddObj Name=Podstawa2.Ramie1 RGB=(200,0,0) Scale=(3,3,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(4,0,0)\n"
      "AddObj Name=Podstawa2.Ramie1.Ramie2 RGB=(100,200,0) Scale=(2,2,1) Shift=(0.5,0,0) RotXYZ_deg=(0,-45,0) Trans_m=(3,0,0)\n";

  sender.Send(sConfigCmds);

  sender.Send("Close\n");
  sender.CancelCountinueLooping();
  Thread4Sending.join();
  return 0;
}


bool ExecPreprocesor( const char * NazwaPliku, istringstream &IStrm4Cmds )
{
    string Cmd4Preproc = "cpp -P ";
    char Line[LINE_SIZE];
    ostringstream OTmpStrm;
    Cmd4Preproc += NazwaPliku;
    FILE* pProc = popen(Cmd4Preproc.c_str(),"r");

    if (!pProc) return false;
    while (fgets(Line,LINE_SIZE,pProc)) OTmpStrm << Line;
    IStrm4Cmds.str(OTmpStrm.str());
    return pclose(pProc) == 0;
}


