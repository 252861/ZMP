#include "Set4LibInterfaces.hh"

Set4LibInterfaces::Set4LibInterfaces()
{
    
}

void Set4LibInterfaces::LibRead()
{
    LibList.insert(pair<string,LibInterface*>("Move", move));
    LibList.insert(pair<string,LibInterface*>("Set", set));
    LibList.insert(pair<string,LibInterface*>("Rotate", rotate));
    LibList.insert(pair<string,LibInterface*>("Pause", pause));
}

bool Set4LibInterfaces::ParamOpen(istringstream &StringStream, Set4LibInterfaces LibraryOpen)
{
    string pomStr;
    Interp4Command *pomCMD;

    while (StringStream >> pomStr)
    {
        if (LibraryOpen.LibList.find(pomStr) == LibraryOpen.LibList.end())
        {
            cerr << "Error 404! Komendy .... " << pomStr << " .... nie znaleziono." << endl;
            break;
        }

        pomCMD = LibraryOpen.LibList[pomStr]->pCreateCmd();

        if (!pomCMD->ReadParams(StringStream))
        {
            cerr << "Blad wczytywania parametrow!" << endl;
        }

        pomCMD->PrintCmd();
    }
    
    return 0;
}


Set4LibInterfaces::~Set4LibInterfaces()
{
    
}