// Jakub Ggorowski
// 252861
// 
// wersja: 2
//   data: 18.10.2022

#include <iostream>
#include <dlfcn.h>
#include <cassert>
#include "LibInterface.hh"
#include "Interp4Command.hh"
#include "MobileObj.hh"

using namespace std;


int main()
{
        cout << endl;
        cout << pCmd->GetCmdName() << endl;
        cout << endl;
        pCmd->PrintSyntax();
        cout << endl;
        pCmd->PrintCmd();
        cout << endl;
    return 0;
}
