#ifndef  LIBINTERFACE_HH
#define  LIBINTERFACE_HH

#include <iostream>
#include <dlfcn.h>
#include <cassert>
#include <cstdio>
#include <sstream>
#include "MobileObj.hh"
#include "Interp4Command.hh"

/*!
 * \file
 * \brief Definicja klasy LibInterface
 *
 * Klasa obsuguje biblioteki.
 */

 class LibInterface {
  public:

    void* LibHandler;
    Interp4Command *(*pCreateCmd)(void);

    //konstruktor
    LibInterface(std::string path);
    //destruktor
    ~LibInterface();

    std::string CmdName;
    
 };
#endif  //LIBINTERFACE_HH