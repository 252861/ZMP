#ifndef  LIBINTERFACE_HH
#define  LIBINTERFACE_HH

#include <iostream>
#include <dlfcn.h>
#include <cassert>
#include "MobileObj.hh"
#include "Interp4Command.hh"

/*!
 * \file
 * \brief Definicja klasy LibInterface
 *
 * Klasa obsuguje biblioteki.
 */

 class LibInterface {
  public:

    void* handler;

    LibInterface;
    ~LibInterface;
    
 };
#endif  LIBINTERFACE_HH