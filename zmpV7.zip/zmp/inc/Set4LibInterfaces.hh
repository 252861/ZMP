#ifndef SET4LIBINTERFACES_HH
#define SET4LIBINTERFACES_HH

#include <iostream>
#include <dlfcn.h>
#include <cassert>
#include <cstdio>
#include <sstream>
#include <string>
#include <map>
#include "LibInterface.hh"
#include "Interp4Command.hh"
#include "MobileObj.hh"


using namespace std;

#define MOV "libs/libInterp4Move.so"
#define SET "libs/libInterp4Set.so"
#define ROT "libs/libInterp4Rotate.so"
#define PAS "libs/libInterp4Pause.so"

class Set4LibInterfaces{

    map<string,LibInterface*> LibList;

    LibInterface *move   = new LibInterface(MOV);
    LibInterface *set    = new LibInterface(SET);
    LibInterface *rotate = new LibInterface(ROT);
    LibInterface *pause  = new LibInterface(PAS);

    public:

    Set4LibInterfaces(); //konstruktor
    ~Set4LibInterfaces();//destruktor

    void LibRead();
    bool ParamOpen(istringstream &StringStream, Set4LibInterfaces LibraryOpen);
};



#endif