// Jakub Ggorowski
// 252861
// 
// wersja: 6
//   data: 16.11.2022

#include <iostream>
#include <dlfcn.h>
#include <cassert>
#include <cstdio>
#include <sstream>
#include "LibInterface.hh"
#include "Interp4Command.hh"
#include "MobileObj.hh"
#include "Set4LibInterfaces.hh"

using namespace std;

#define LINE_SIZE 500


bool ExecPreprocesor( const char * NazwaPliku, istringstream &IStrm4Cmds );

int main()
{
  Set4LibInterfaces LibraryOpen;
  istringstream StringStream;
  ExecPreprocesor("task.cmd", StringStream);
  LibraryOpen.LibRead();
  LibraryOpen.ParamOpen(StringStream, LibraryOpen);
 
  return 0;
}


bool ExecPreprocesor( const char * NazwaPliku, istringstream &IStrm4Cmds )
{
    string Cmd4Preproc = "cpp -P ";
    char Line[LINE_SIZE];
    ostringstream OTmpStrm;
    Cmd4Preproc += NazwaPliku;
    FILE* pProc = popen(Cmd4Preproc.c_str(),"r");

    if (!pProc) return false;
    while (fgets(Line,LINE_SIZE,pProc)) OTmpStrm << Line;
    IStrm4Cmds.str(OTmpStrm.str());
    return pclose(pProc) == 0;
}


